#ifndef BE_INLINE_H_
#define BE_INLINE_H_
object Dadd(d_ptr a, d_ptr b);
object Dminus(d_ptr a, d_ptr b);
object Dmultiply(d_ptr a, d_ptr b);
#endif
