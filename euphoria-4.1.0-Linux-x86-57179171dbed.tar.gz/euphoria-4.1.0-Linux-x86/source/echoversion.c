#include <stdio.h>
#include "version.h"

int main(){
	printf("%d.%d.%d", MAJ_VER, MIN_VER, PAT_VER );
	return 0;
}
