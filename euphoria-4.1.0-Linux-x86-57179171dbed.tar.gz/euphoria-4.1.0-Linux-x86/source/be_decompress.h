#ifndef BE_DECOMPRESS_H_
#define BE_DECOMPRESS_H_
#include <stdint.h>
object decompress(uintptr_t c);
#endif
