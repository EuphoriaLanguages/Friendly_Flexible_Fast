integer val = 1
ifdef TWO then
	val *= 2
end ifdef
? val
